---
layout: post
title: Second Blog Post
---
This is my second blog post which is currently a draft. Draft posts live in `_drafts` and are not published to the live website.